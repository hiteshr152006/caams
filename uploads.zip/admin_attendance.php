<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$message = "";

// Fetch all approved students
$students = mysqli_query($conn, "SELECT * FROM students WHERE status = 'Approved' ORDER BY student_id ASC");

// When form is submitted
if (isset($_POST['submit_attendance'])) {
    $date = $_POST['date'];
    $subject = $_POST['subject'];

    foreach ($_POST['status'] as $student_id => $status) {
        // Check if already marked
        $check = mysqli_query($conn, "SELECT * FROM attendance WHERE student_id='$student_id' AND date='$date' AND subject='$subject'");
        
        if (mysqli_num_rows($check) == 0) {
            $sql = "INSERT INTO attendance (student_id, subject, date, status) 
                    VALUES ('$student_id', '$subject', '$date', '$status')";
            mysqli_query($conn, $sql);
        }
    }
    $message = "Attendance marked successfully for $subject on $date";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: block;
            padding: 30px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #00d4ff;
        }
        .logout {
            background-color: #ff4d4d;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
        }
        .menu {
            margin-bottom: 30px;
        }
        .menu a {
            color: #00d4ff;
            margin-right: 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .form-box {
            background-color: #1a1a1a;
            padding: 25px;
            border-radius: 12px;
            border: 1px solid #333;
            margin-bottom: 30px;
            max-width: 500px;
        }
        label {
            color: #ccc;
            display: block;
            margin-bottom: 6px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            background-color: #0f0f0f;
            border: 1px solid #444;
            border-radius: 8px;
            color: white;
            margin-bottom: 15px;
        }
        button {
            padding: 12px 25px;
            background-color: #00d4ff;
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #1a1a1a;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #333;
        }
        th {
            background-color: #111;
            color: #00d4ff;
        }
        .message {
            background-color: #003322;
            color: #00ff88;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Toggle Switch Style */
        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #00c853; /* Green = Present */
            transition: .3s;
            border-radius: 30px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        input:checked + .slider {
            background-color: #ff4d4d; /* Red = Absent */
        }
        input:checked + .slider:before {
            transform: translateX(30px);
        }
        .status-text {
            margin-left: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Mark Attendance</h1>
        <a href="logout.php" class="logout">Logout</a>
    </div>

    <div class="menu">
        <a href="admin_dashboard.php">Admission Requests</a>
        <a href="admin_attendance.php">Attendance</a>
        <a href="admin_marks.php">Marks</a>
        <a href="admin_timetable.php">Timetable</a>
        <a href="admin_materials.php">Study Materials</a>
    </div>

    <?php if ($message != "") { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <div class="form-box">
        <form method="POST">
            <label>Date</label>
            <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" required>

            <label>Subject</label>
            <select name="subject" required>
                <option value="">Select Subject</option>
                <option value="Programming in C">Programming in C</option>
                <option value="Database Management">Database Management</option>
                <option value="Web Development">Web Development</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Computer Networks">Computer Networks</option>
            </select>

            <button type="submit" name="load">Load Students</button>
        </form>
    </div>

    <?php if (isset($_POST['load']) || isset($_POST['submit_attendance'])) { ?>
        <form method="POST">
            <input type="hidden" name="date" value="<?php echo $_POST['date']; ?>">
            <input type="hidden" name="subject" value="<?php echo $_POST['subject']; ?>">

            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Attendance</th>
                </tr>

                <?php 
                mysqli_data_seek($students, 0); // Reset pointer
                while ($row = mysqli_fetch_assoc($students)) { ?>
                    <tr>
                        <td><?php echo $row['student_id']; ?></td>
                        <td><?php echo $row['full_name']; ?></td>
                        <td>
                            <label class="switch">
                                <input type="checkbox" name="status[<?php echo $row['student_id']; ?>]" value="Absent" onchange="updateText(this)">
                                <span class="slider"></span>
                            </label>
                            <span class="status-text" style="color:#00c853;">Present</span>
                        </td>
                    </tr>
                <?php } ?>
            </table>

            <br>
            <button type="submit" name="submit_attendance">Submit Attendance</button>
        </form>
    <?php } ?>

    <script>
        function updateText(checkbox) {
            const text = checkbox.parentElement.nextElementSibling;
            if (checkbox.checked) {
                text.innerText = "Absent";
                text.style.color = "#ff4d4d";
            } else {
                text.innerText = "Present";
                text.style.color = "#00c853";
            }
        }
    </script>
</body>
</html>