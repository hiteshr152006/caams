<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$message = "";

// Fetch approved students
$students = mysqli_query($conn, "SELECT * FROM students WHERE status = 'Approved' ORDER BY student_id ASC");

if (isset($_POST['submit_marks'])) {
    $subject = $_POST['subject'];

    foreach ($_POST['ia'] as $student_id => $ia) {
        $lab = $_POST['lab'][$student_id];
        $sessional = $_POST['sessional'][$student_id];

        // Check if marks already exist
        $check = mysqli_query($conn, "SELECT * FROM marks WHERE student_id='$student_id' AND subject='$subject'");
        
        if (mysqli_num_rows($check) > 0) {
            // Update existing
            $sql = "UPDATE marks SET ia_marks='$ia', lab_marks='$lab', sessional_marks='$sessional' 
                    WHERE student_id='$student_id' AND subject='$subject'";
        } else {
            // Insert new
            $sql = "INSERT INTO marks (student_id, subject, ia_marks, lab_marks, sessional_marks) 
                    VALUES ('$student_id', '$subject', '$ia', '$lab', '$sessional')";
        }
        mysqli_query($conn, $sql);
    }
    $message = "Marks saved successfully for $subject";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Marks</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: block;
            padding: 30px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #00d4ff;
        }
        .logout {
            background-color: #ff4d4d;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
        }
        .menu {
            margin-bottom: 30px;
        }
        .menu a {
            color: #00d4ff;
            margin-right: 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .form-box {
            background-color: #1a1a1a;
            padding: 25px;
            border-radius: 12px;
            border: 1px solid #333;
            margin-bottom: 30px;
            max-width: 400px;
        }
        label {
            color: #ccc;
            display: block;
            margin-bottom: 6px;
        }
        select {
            width: 100%;
            padding: 10px;
            background-color: #0f0f0f;
            border: 1px solid #444;
            border-radius: 8px;
            color: white;
            margin-bottom: 15px;
        }
        button {
            padding: 12px 25px;
            background-color: #00d4ff;
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #1a1a1a;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
        }
        th {
            background-color: #111;
            color: #00d4ff;
        }
        input[type="number"] {
            width: 80px;
            padding: 8px;
            background-color: #0f0f0f;
            border: 1px solid #444;
            border-radius: 6px;
            color: white;
        }
        .message {
            background-color: #003322;
            color: #00ff88;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Enter Marks</h1>
        <a href="logout.php" class="logout">Logout</a>
    </div>

    <div class="menu">
        <a href="admin_dashboard.php">Admission Requests</a>
        <a href="admin_attendance.php">Attendance</a>
        <a href="admin_marks.php">Marks</a>
        <a href="admin_timetable.php">Timetable</a>
        <a href="admin_materials.php">Study Materials</a>
    </div>

    <?php if ($message != "") { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <div class="form-box">
        <form method="POST">
            <label>Select Subject</label>
            <select name="subject" required>
                <option value="">Select Subject</option>
                <option value="Programming in C">Programming in C</option>
                <option value="Database Management">Database Management</option>
                <option value="Web Development">Web Development</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Computer Networks">Computer Networks</option>
            </select>
            <button type="submit" name="load">Load Students</button>
        </form>
    </div>

    <?php if (isset($_POST['load']) || isset($_POST['submit_marks'])) { ?>
        <form method="POST">
            <input type="hidden" name="subject" value="<?php echo $_POST['subject']; ?>">

            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>IA Marks</th>
                    <th>Lab Marks</th>
                    <th>Sessional Marks</th>
                </tr>

                <?php 
                mysqli_data_seek($students, 0);
                while ($row = mysqli_fetch_assoc($students)) { ?>
                    <tr>
                        <td><?php echo $row['student_id']; ?></td>
                        <td><?php echo $row['full_name']; ?></td>
                        <td><input type="number" name="ia[<?php echo $row['student_id']; ?>]" min="0" max="30" step="0.5" value="0"></td>
                        <td><input type="number" name="lab[<?php echo $row['student_id']; ?>]" min="0" max="30" step="0.5" value="0"></td>
                        <td><input type="number" name="sessional[<?php echo $row['student_id']; ?>]" min="0" max="30" step="0.5" value="0"></td>
                    </tr>
                <?php } ?>
            </table>

            <br>
            <button type="submit" name="submit_marks">Save Marks</button>
        </form>
    <?php } ?>
</body>
</html>