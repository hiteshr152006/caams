<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Approve Student
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    
    // Generate Student ID (Example: STU2024001)
    $student_id = "STU" . date("Y") . str_pad($id, 3, "0", STR_PAD_LEFT);
    $password = "student123"; // Default password

    $sql = "UPDATE students SET status='Approved', student_id='$student_id', password='$password' WHERE id=$id";
    mysqli_query($conn, $sql);
    header("Location: admin_dashboard.php");
    exit();
}

// Reject Student
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    $sql = "UPDATE students SET status='Rejected' WHERE id=$id";
    mysqli_query($conn, $sql);
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch all students
$result = mysqli_query($conn, "SELECT * FROM students ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: block;
            padding: 30px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #00d4ff;
        }
        .logout {
            background-color: #ff4d4d;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #1a1a1a;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #333;
        }
        th {
            background-color: #111;
            color: #00d4ff;
        }
        .btn {
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            font-size: 0.9rem;
            margin-right: 5px;
        }
        .approve {
            background-color: #00c853;
        }
        .reject {
            background-color: #ff4d4d;
        }
        .status-pending {
            color: #ffc107;
        }
        .status-approved {
            color: #00c853;
        }
        .status-rejected {
            color: #ff4d4d;
        }
        .menu {
            margin-bottom: 30px;
        }
        .menu a {
            color: #00d4ff;
            margin-right: 20px;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Admin Dashboard</h1>
        <a href="logout.php" class="logout">Logout</a>
    </div>

    <div class="menu">
         <a href="admin_dashboard.php">Admission Requests</a>
         <a href="admin_attendance.php">Attendance</a>
         <a href="admin_marks.php">Marks</a>
         <a href="admin_timetable.php">Timetable</a>
         <a href="admin_materials.php">Study Materials</a>
    </div>

    <h2 style="margin-bottom: 20px; color: #ccc;">Student Applications</h2>

    <table>
    <tr>
        <th>#</th>
        <th>Student ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Course</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td>
                <?php 
                    if ($row['student_id']) {
                        echo $row['student_id'];
                    } else {
                        echo "-";
                    }
                ?>
            </td>
            <td><?php echo $row['full_name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['course']; ?></td>
            <td class="status-<?php echo strtolower($row['status']); ?>">
                <?php echo $row['status']; ?>
            </td>
            <td>
                <?php if ($row['status'] == 'Pending') { ?>
                    <a href="?approve=<?php echo $row['id']; ?>" class="btn approve">Approve</a>
                    <a href="?reject=<?php echo $row['id']; ?>" class="btn reject">Reject</a>
                <?php } else {
                    echo "-";
                } ?>
            </td>
        </tr>
    <?php } ?>
</table>
</body>
</html>