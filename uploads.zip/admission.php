<?php
include 'config.php';

$message = "";

if (isset($_POST['submit'])) {
    $full_name = $_POST['full_name'];
    $email     = $_POST['email'];
    $phone     = $_POST['phone'];
    $dob       = $_POST['dob'];
    $gender    = $_POST['gender'];
    $address   = $_POST['address'];
    $course    = $_POST['course'];

    // File upload handling
    $photo_name = $_FILES['photo']['name'];
    $mark10_name = $_FILES['marksheet_10th']['name'];
    $mark12_name = $_FILES['marksheet_12th']['name'];

    $photo_tmp = $_FILES['photo']['tmp_name'];
    $mark10_tmp = $_FILES['marksheet_10th']['tmp_name'];
    $mark12_tmp = $_FILES['marksheet_12th']['tmp_name'];

    // Create uploads folder if not exists
    if (!file_exists('uploads')) {
        mkdir('uploads', 0777, true);
    }

    $photo_path = "uploads/" . time() . "_photo_" . $photo_name;
    $mark10_path = "uploads/" . time() . "_10th_" . $mark10_name;
    $mark12_path = "uploads/" . time() . "_12th_" . $mark12_name;

    move_uploaded_file($photo_tmp, $photo_path);
    move_uploaded_file($mark10_tmp, $mark10_path);
    move_uploaded_file($mark12_tmp, $mark12_path);

    $sql = "INSERT INTO students (full_name, email, phone, dob, gender, address, course, photo, marksheet_10th, marksheet_12th) 
            VALUES ('$full_name', '$email', '$phone', '$dob', '$gender', '$address', '$course', '$photo_path', '$mark10_path', '$mark12_path')";

    if (mysqli_query($conn, $sql)) {
        $message = "Application submitted successfully! Please wait for admin approval.";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Form</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-container {
            background-color: #1a1a1a;
            padding: 40px;
            border-radius: 15px;
            width: 100%;
            max-width: 600px;
            margin: 40px auto;
            border: 1px solid #333;
        }
        .form-container h2 {
            text-align: center;
            color: #00d4ff;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #ccc;
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            background-color: #0f0f0f;
            border: 1px solid #444;
            border-radius: 8px;
            color: white;
            font-size: 1rem;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #00d4ff;
        }
        button {
            width: 100%;
            padding: 14px;
            background-color: #00d4ff;
            color: #000;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #00b8e0;
        }
        .message {
            text-align: center;
            margin-bottom: 20px;
            color: #00ff88;
        }
        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #00d4ff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Student Admission Form</h2>

        <?php if ($message != "") { ?>
            <div class="message"><?php echo $message; ?></div>
        <?php } ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" required>
            </div>

            <div class="form-group">
                <label>Date of Birth</label>
                <input type="date" name="dob" required>
            </div>

            <div class="form-group">
                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label>Address</label>
                <textarea name="address" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label>Course</label>
                <select name="course" required>
                    <option value="">Select Course</option>
                    <option value="BCA">BCA</option>
                    <option value="BBA">BBA</option>
                    <option value="BSc">BSc</option>
                    <option value="BA">BA</option>
                </select>
            </div>

            <div class="form-group">
                <label>Passport Size Photo</label>
                <input type="file" name="photo" accept="image/*" required>
            </div>

            <div class="form-group">
                <label>10th Marksheet</label>
                <input type="file" name="marksheet_10th" accept="image/*,.pdf" required>
            </div>

            <div class="form-group">
                <label>12th Marksheet</label>
                <input type="file" name="marksheet_12th" accept="image/*,.pdf" required>
            </div>

            <button type="submit" name="submit">Submit Application</button>
        </form>

        <a href="index.php" class="back">← Back to Home</a>
    </div>
</body>
</html> 